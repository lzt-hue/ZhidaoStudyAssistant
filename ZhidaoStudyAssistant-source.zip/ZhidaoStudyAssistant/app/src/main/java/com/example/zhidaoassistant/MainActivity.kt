package com.example.zhidaoassistant

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private data class Course(val id: Long, val name: String, val chapters: Int, val done: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { StudyAssistantApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyAssistantApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("study_data", 0) }
    var courseName by remember { mutableStateOf("") }
    var courses by remember { mutableStateOf(loadCourses(prefs.getString("courses", "[]") ?: "[]")) }
    var seconds by remember { mutableLongStateOf(prefs.getLong("study_seconds", 0L)) }
    var running by remember { mutableStateOf(false) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var question by remember { mutableStateOf("") }

    LaunchedEffect(running) {
        while (running) {
            kotlinx.coroutines.delay(1000)
            seconds = prefs.getLong("study_seconds", 0L) + TimeUnit.MILLISECONDS.toSeconds(SystemClock.elapsedRealtime() - startedAt)
        }
    }

    fun saveCourses() {
        val arr = JSONArray()
        courses.forEach { c -> arr.put(JSONObject().put("id", c.id).put("name", c.name).put("chapters", c.chapters).put("done", c.done)) }
        prefs.edit().putString("courses", arr.toString()).apply()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("知到学习助手") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("真实学习计时", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(formatDuration(seconds), style = MaterialTheme.typography.headlineMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (!running) { startedAt = SystemClock.elapsedRealtime(); running = true }
                            }, enabled = !running) { Text("开始") }
                            OutlinedButton(onClick = {
                                if (running) {
                                    val elapsed = TimeUnit.MILLISECONDS.toSeconds(SystemClock.elapsedRealtime() - startedAt)
                                    seconds = prefs.getLong("study_seconds", 0L) + elapsed
                                    prefs.edit().putLong("study_seconds", seconds).apply()
                                    running = false
                                }
                            }, enabled = running) { Text("暂停并保存") }
                            TextButton(onClick = {
                                running = false; seconds = 0L
                                prefs.edit().putLong("study_seconds", 0L).apply()
                            }) { Text("清零") }
                        }
                        Text("计时仅记录本机实际开启计时的时间，不会修改知到平台记录。", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Text("课程清单", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = courseName, onValueChange = { courseName = it }, label = { Text("输入课程名称") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = {
                    val n = courseName.trim()
                    if (n.isNotEmpty()) {
                        courses = courses + Course(System.currentTimeMillis(), n, 0, 0)
                        courseName = ""; saveCourses()
                    }
                }, modifier = Modifier.padding(top = 6.dp)) { Text("添加课程") }
            }
            if (courses.isEmpty()) item { Text("还没有课程，输入课程名称后添加。", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(courses, key = { it.id }) { course ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(course.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("已完成 ${course.done} / ${course.chapters} 个章节")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                courses = courses.map { if (it.id == course.id) it.copy(chapters = it.chapters + 1) else it }; saveCourses()
                            }) { Text("章节总数 +1") }
                            OutlinedButton(onClick = {
                                courses = courses.map { if (it.id == course.id) it.copy(done = (it.done + 1).coerceAtMost(it.chapters)) else it }; saveCourses()
                            }, enabled = course.done < course.chapters) { Text("完成章节 +1") }
                            TextButton(onClick = { courses = courses.filterNot { it.id == course.id }; saveCourses() }) { Text("删除") }
                        }
                    }
                }
            }
            item {
                Text("题目解析备忘", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text("粘贴题目或知识点") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Text("此版本先提供本地题目整理入口；可将题目复制到可信的学习资料或 AI 助手中获取讲解。不会自动提交考试或代答考核。", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text("使用说明", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("本工具是独立的学习记录助手，不连接或控制智慧树官方 APP，也不读取账号密码。课程章节数量和完成状态由你手动维护。", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

private fun loadCourses(raw: String): List<Course> = try {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        Course(o.getLong("id"), o.getString("name"), o.optInt("chapters"), o.optInt("done"))
    }
} catch (_: Exception) { emptyList() }

private fun formatDuration(total: Long): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
