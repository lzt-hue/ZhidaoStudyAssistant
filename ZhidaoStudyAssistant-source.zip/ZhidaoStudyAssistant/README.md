# 知到学习助手（Android 项目源码）

这是一个独立的本地学习记录工具原型，不是智慧树官方客户端，也不连接或控制知到 APP。

## 当前功能
- 本地添加、删除课程
- 手动维护章节总数与完成数量
- 本机真实学习计时，暂停后保存
- 题目/知识点文本备忘入口
- 不收集账号密码，不伪造学习时长，不绕过平台检测，不自动代答考试

## 构建 APK
1. 在电脑上安装 Android Studio（建议较新稳定版）和 Android SDK Platform 36。
2. 用 Android Studio 打开本项目根目录 `ZhidaoStudyAssistant`。
3. 等待 Gradle Sync 完成。
4. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. 构建成功后，APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 兼容性
- minSdk 26（Android 8.0）
- compileSdk 36
- targetSdk 35
- Kotlin + Jetpack Compose

## 说明
当前交付的是可继续开发的 Android Studio 项目源码，不是已经编译、签名并在 OPPO Android 17 真机验证过的 APK。由于本构建环境没有安装 Android SDK/Gradle，无法在这里完成 APK 编译与真机验证。
